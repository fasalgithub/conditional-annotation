package com.conditional.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConditionalApplicationTests {

	@Test
	void contextLoads() {
	}

}
