package com.conditional.demo.beans;

import org.springframework.stereotype.Component;

@Component("bean")
public class Bean {

}
