package com.conditional.demo.beans;

import org.springframework.stereotype.Component;


public class NoBean {
	
	

}
