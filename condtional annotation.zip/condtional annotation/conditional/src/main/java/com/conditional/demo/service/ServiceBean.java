package com.conditional.demo.service;

import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.stereotype.Service;

import com.conditional.demo.beans.Bean;

@Service
@ConditionalOnBean(Bean.class)
public class ServiceBean 
{

	public String myService() 
	{
	     return "My Service";
	}
	
}
