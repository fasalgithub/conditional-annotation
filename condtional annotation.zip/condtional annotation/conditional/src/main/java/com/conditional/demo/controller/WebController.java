package com.conditional.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.boot.autoconfigure.condition.ConditionalOnJava;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.condition.ConditionalOnResource;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWarDeployment;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.boot.system.JavaVersion;
import org.springframework.context.annotation.Conditional;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.conditional.demo.beans.Bean;
import com.conditional.demo.beans.NoBean;
import com.conditional.demo.myconditional.MyConditionalClass;
import com.conditional.demo.service.ServiceBean;

@RestController
/*@ConditionalOnProperty(value = "my.password",havingValue = "xxxyyyzzz")*/
/*@ConditionalOnJava(value = JavaVersion.EIGHT)*/
/*@ConditionalOnBean(Bean.class)*/
/*@ConditionalOnMissingBean(NoBean.class)*/
/*@ConditionalOnExpression("${logging.enabled:true}")*/
/*@ConditionalOnClass(Bean.class)*/
/*@ConditionalOnWarDeployment*/
/* @ConditionalOnWebApplication */
@ConditionalOnResource(resources = "/hell.txt")
@Conditional(MyConditionalClass.class)
public class WebController 
{
	@Autowired
	private ServiceBean Service;
	
	@RequestMapping("/controller")
	private String getMyStatus() 
	{
		return Service.myService();
	}

}
